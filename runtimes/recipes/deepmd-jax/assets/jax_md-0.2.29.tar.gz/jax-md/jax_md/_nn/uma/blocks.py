"""UMA model blocks.

This module provides the building blocks for the UMA model, including
Edgewise (message passing) and Atomwise (feed-forward) operations.

Ported from FairChem's UMA implementation.
"""

from __future__ import annotations

from typing import List, Literal, Sequence

import flax.linen as nn
import jax
import jax.numpy as jnp

from jax_md._nn.uma.nn.so2_layers import SO2Convolution
from jax_md._nn.uma.nn.so3_layers import SO3Linear
from jax_md._nn.uma.nn.activation import (
  GateActivation,
  SeparableS2Activation,
)
from jax_md._nn.uma.nn.layer_norm import get_normalization_layer


class Edgewise(nn.Module):
  """Edgewise (message passing) module.

  Performs SO(2) convolutions to pass messages along edges.

  Attributes:
      sphere_channels: Number of spherical channels.
      hidden_channels: Number of hidden channels.
      lmax: Maximum degree l.
      mmax: Maximum order m.
      edge_channels_list: Channel dimensions for edge features.
      m_size: List of number of coefficients for each m.
      cutoff: Distance cutoff.
      act_type: Type of activation ('gate' or 's2').
  """

  sphere_channels: int
  hidden_channels: int
  lmax: int
  mmax: int
  edge_channels_list: List[int]
  m_size: Sequence[int]
  act_type: str = 'gate'  # 'gate' or 's2'
  to_grid_mat: jnp.ndarray | None = None
  from_grid_mat: jnp.ndarray | None = None
  mapping_to_m: jnp.ndarray | None = None
  use_kernels: bool = False

  @nn.compact
  def __call__(
    self,
    x: jnp.ndarray,
    x_edge: jnp.ndarray,
    edge_index: jnp.ndarray,
    wigner_and_M_mapping: jnp.ndarray,
    wigner_and_M_mapping_inv: jnp.ndarray,
    wigner: jnp.ndarray | None,
    wigner_inv: jnp.ndarray | None,
    edge_envelope: jnp.ndarray,
    node_offset: int = 0,
  ) -> jnp.ndarray:
    """Apply edgewise message passing.

    Args:
        x: Node features, shape [num_nodes, num_m_coeffs, sphere_channels].
        x_edge: Edge scalar features, shape [num_edges, edge_channels].
        edge_index: Edge connectivity, shape [2, num_edges].
        wigner_and_M_mapping: Forward Wigner rotation + M mapping.
        wigner_and_M_mapping_inv: Inverse Wigner rotation + M mapping.
        edge_envelope: Edge envelope values, shape [num_edges, 1, 1].
        node_offset: Offset for node indices.

    Returns:
        Message contribution to add to nodes, shape [num_nodes, ...].
    """
    # Determine extra output channels for gating
    if self.act_type == 'gate':
      extra_m0_output_channels = self.lmax * self.hidden_channels
    else:
      extra_m0_output_channels = self.hidden_channels

    # First SO2 convolution
    so2_conv_1 = SO2Convolution(
      sphere_channels=2 * self.sphere_channels,  # Concatenated source + target
      m_output_channels=self.hidden_channels,
      lmax=self.lmax,
      mmax=self.mmax,
      m_size=self.m_size,
      internal_weights=False,
      edge_channels_list=self.edge_channels_list,
      extra_m0_output_channels=extra_m0_output_channels,
      name='so2_conv_1',
    )

    # Second SO2 convolution
    so2_conv_2 = SO2Convolution(
      sphere_channels=self.hidden_channels,
      m_output_channels=self.sphere_channels,
      lmax=self.lmax,
      mmax=self.mmax,
      m_size=self.m_size,
      internal_weights=True,
      edge_channels_list=None,
      extra_m0_output_channels=None,
      name='so2_conv_2',
    )

    # Activation
    if self.act_type == 'gate':
      act = GateActivation(
        lmax=self.lmax,
        mmax=self.mmax,
        num_channels=self.hidden_channels,
        m_prime=True,
        name='act',
      )
    else:
      act = SeparableS2Activation(
        lmax=self.lmax,
        mmax=self.mmax,
        to_grid_mat=jnp.asarray(self.to_grid_mat),
        from_grid_mat=jnp.asarray(self.from_grid_mat),
        mapping_to_m=self.mapping_to_m,
        name='act',
      )

    # Gather source/target node features and rotate to edge-aligned frames.
    if (
      self.use_kernels
      and wigner is not None
      and wigner.shape[-2:] == (9, 9)
      and x.shape[-2] == 9
      and jax.default_backend() == 'gpu'
    ):
      from jax_md._nn.uma import kernels

      x_message = kernels.node_to_edge_wigner_permute(x, edge_index, wigner)
    else:
      # Get source and target node features
      if x.shape[0] == 0:
        return jnp.zeros_like(x)
      sender = jnp.where(edge_index[0] >= 0, edge_index[0], x.shape[0])
      receiver = jnp.where(edge_index[1] >= 0, edge_index[1], x.shape[0])
      x_source = jnp.take(x, sender, axis=0, mode='fill', fill_value=0.0)
      x_target = jnp.take(x, receiver, axis=0, mode='fill', fill_value=0.0)

      # Concatenate source and target features
      x_message = jnp.concatenate([x_source, x_target], axis=2)

      # Rotate to edge-aligned frame
      x_message = jnp.einsum('nmj,njc->nmc', wigner_and_M_mapping, x_message)

    # First SO2 convolution
    x_message, x_0_gating = so2_conv_1(x_message, x_edge)

    # Activation (m-prime)
    x_message = act(x_0_gating, x_message)

    # Second SO2 convolution
    x_message = so2_conv_2(x_message, x_edge)
    if isinstance(x_message, tuple):
      # Not reached: so2_conv_2 has no extra m0 outputs.
      x_message = x_message[0]

    # Apply envelope
    x_message = x_message * edge_envelope

    # Rotate back to global frame and aggregate to target nodes
    if (
      self.use_kernels
      and wigner_inv is not None
      and wigner_inv.shape[-2:] == (9, 9)
      and x_message.shape[-2] == 9
      and jax.default_backend() == 'gpu'
      and node_offset == 0
    ):
      from jax_md._nn.uma import kernels

      return kernels.edge_to_node_wigner_inverse(
        x_message, edge_index, wigner_inv, x.shape[0]
      )
    else:
      # Rotate back to global frame
      x_message = jnp.einsum(
        'njm,nmc->njc', wigner_and_M_mapping_inv, x_message
      )

      # Aggregate messages onto target nodes using scatter-add
      target_indices = edge_index[1] - node_offset
      target_indices = jnp.where(
        target_indices >= 0, target_indices, x.shape[0]
      )
      return jnp.zeros_like(x).at[target_indices].add(x_message, mode='drop')


class SpectralAtomwise(nn.Module):
  """Spectral atomwise feed-forward module.

  Uses SO(3) linear layers with gated activation.

  Attributes:
      sphere_channels: Number of spherical channels.
      hidden_channels: Number of hidden channels.
      lmax: Maximum degree l.
      mmax: Maximum order m.
  """

  sphere_channels: int
  hidden_channels: int
  lmax: int

  @nn.compact
  def __call__(self, x: jnp.ndarray) -> jnp.ndarray:
    """Apply spectral atomwise FFN.

    Args:
        x: Node features, shape [num_nodes, (lmax+1)^2, sphere_channels].

    Returns:
        Updated features, same shape.
    """
    # Scalar MLP for gating
    scalar_input = x[:, 0:1, :].squeeze(1)
    scalar_mlp = nn.Sequential(
      [
        nn.Dense(self.lmax * self.hidden_channels),
        nn.silu,
      ]
    )
    gating_scalars = scalar_mlp(scalar_input)

    # First SO3 linear
    so3_linear_1 = SO3Linear(
      out_features=self.hidden_channels,
      lmax=self.lmax,
      name='so3_linear_1',
    )
    x = so3_linear_1(x)

    # Gate activation
    act = GateActivation(
      lmax=self.lmax,
      mmax=self.lmax,
      num_channels=self.hidden_channels,
      name='act',
    )
    x = act(gating_scalars, x)

    # Second SO3 linear
    so3_linear_2 = SO3Linear(
      out_features=self.sphere_channels,
      lmax=self.lmax,
      name='so3_linear_2',
    )
    x = so3_linear_2(x)

    return x


class GridAtomwise(nn.Module):
  """Grid-based atomwise feed-forward module.

  Projects to grid, applies MLP, projects back.

  Attributes:
      sphere_channels: Number of spherical channels.
      hidden_channels: Number of hidden channels.
      lmax: Maximum degree l.
      mmax: Maximum order m.
      to_grid_mat: Matrix for coefficients -> grid transformation.
      from_grid_mat: Matrix for grid -> coefficients transformation.
  """

  sphere_channels: int
  hidden_channels: int
  to_grid_mat: jnp.ndarray
  from_grid_mat: jnp.ndarray

  @nn.compact
  def __call__(self, x: jnp.ndarray) -> jnp.ndarray:
    """Apply grid atomwise FFN.

    Args:
        x: Node features, shape [num_nodes, (lmax+1)^2, sphere_channels].

    Returns:
        Updated features, same shape.
    """
    grid_mlp = nn.Sequential(
      [
        nn.Dense(self.hidden_channels, use_bias=False),
        nn.silu,
        nn.Dense(self.hidden_channels, use_bias=False),
        nn.silu,
        nn.Dense(self.sphere_channels, use_bias=False),
      ]
    )

    num_nodes = x.shape[0]
    lat, lon, num_coeffs = self.to_grid_mat.shape
    grid_points = lat * lon

    # Flatten grid dims for efficient matmul dispatch via cuBLAS.
    to_grid_flat = self.to_grid_mat.reshape(grid_points, num_coeffs)
    from_grid_flat = self.from_grid_mat.reshape(grid_points, num_coeffs)

    # Project to grid: [N, coeffs, C] -> [N, grid_points, C]
    x_grid = jnp.einsum('gi,nic->ngc', to_grid_flat, x)

    # Apply MLP per grid point (Dense applies to last dim).
    x_grid = grid_mlp(x_grid)

    # Project back: [N, grid_points, C] -> [N, coeffs, C]
    x = jnp.einsum('gi,ngc->nic', from_grid_flat, x_grid)

    return x


class UMABlock(nn.Module):
  """UMA transformer-like block.

  Combines edgewise (message passing) and atomwise (FFN) operations
  with residual connections and normalization.

  Attributes:
      sphere_channels: Number of spherical channels.
      hidden_channels: Number of hidden channels.
      lmax: Maximum degree l.
      mmax: Maximum order m.
      m_size: List of number of coefficients for each m.
      edge_channels_list: Channel dimensions for edge features.
      cutoff: Distance cutoff.
      norm_type: Type of normalization.
      act_type: Type of activation for edgewise.
      ff_type: Type of feed-forward ('spectral' or 'grid').
      to_grid_mat: Matrix for coefficients -> grid transformation.
      from_grid_mat: Matrix for grid -> coefficients transformation.
  """

  sphere_channels: int
  hidden_channels: int
  lmax: int
  mmax: int
  m_size: Sequence[int]
  edge_channels_list: List[int]
  norm_type: str = 'rms_norm_sh'
  act_type: str = 'gate'  # 'gate' or 's2'
  ff_type: str = 'grid'  # 'spectral' or 'grid'
  to_grid_mat: jnp.ndarray | None = None
  from_grid_mat: jnp.ndarray | None = None
  mapping_to_m: jnp.ndarray | None = None
  use_kernels: bool = False

  @nn.compact
  def __call__(
    self,
    x: jnp.ndarray,
    x_edge: jnp.ndarray,
    edge_index: jnp.ndarray,
    wigner_and_M_mapping: jnp.ndarray,
    wigner_and_M_mapping_inv: jnp.ndarray,
    wigner: jnp.ndarray | None,
    wigner_inv: jnp.ndarray | None,
    edge_envelope: jnp.ndarray,
    sys_node_embedding: jnp.ndarray | None = None,
    node_offset: int = 0,
  ) -> jnp.ndarray:
    """Apply UMA block.

    Args:
        x: Node features, shape [num_nodes, (lmax+1)^2, sphere_channels].
        x_edge: Edge scalar features, shape [num_edges, edge_channels].
        edge_index: Edge connectivity, shape [2, num_edges].
        wigner_and_M_mapping: Forward Wigner rotation + M mapping.
        wigner_and_M_mapping_inv: Inverse Wigner rotation + M mapping.
        edge_envelope: Edge envelope values, shape [num_edges, 1, 1].
        sys_node_embedding: Per-system embedding to add, shape [num_nodes, sphere_channels].
        node_offset: Offset for node indices.

    Returns:
        Updated node features, same shape as x.
    """
    # First residual block: Edgewise
    x_res = x

    # Pre-normalization
    norm_1 = get_normalization_layer(
      self.norm_type,
      lmax=self.lmax,
      num_channels=self.sphere_channels,
      name='norm_1',
    )
    x = norm_1(x)

    # Add system embedding to scalars
    if sys_node_embedding is not None:
      x = x.at[:, 0, :].add(sys_node_embedding)

    # Edgewise message passing
    edgewise = Edgewise(
      sphere_channels=self.sphere_channels,
      hidden_channels=self.hidden_channels,
      lmax=self.lmax,
      mmax=self.mmax,
      edge_channels_list=self.edge_channels_list,
      m_size=self.m_size,
      act_type=self.act_type,
      to_grid_mat=self.to_grid_mat,
      from_grid_mat=self.from_grid_mat,
      mapping_to_m=self.mapping_to_m,
      use_kernels=self.use_kernels,
      name='edge_wise',
    )
    x = edgewise(
      x,
      x_edge,
      edge_index,
      wigner_and_M_mapping,
      wigner_and_M_mapping_inv,
      wigner,
      wigner_inv,
      edge_envelope,
      node_offset,
    )
    x = x + x_res

    # Second residual block: Atomwise
    x_res = x

    # Pre-normalization
    norm_2 = get_normalization_layer(
      self.norm_type,
      lmax=self.lmax,
      num_channels=self.sphere_channels,
      name='norm_2',
    )
    x = norm_2(x)

    # Atomwise FFN
    if self.ff_type == 'spectral':
      atomwise = SpectralAtomwise(
        sphere_channels=self.sphere_channels,
        hidden_channels=self.hidden_channels,
        lmax=self.lmax,
        name='atom_wise',
      )
    else:
      atomwise = GridAtomwise(
        sphere_channels=self.sphere_channels,
        hidden_channels=self.hidden_channels,
        to_grid_mat=jnp.asarray(self.to_grid_mat),
        from_grid_mat=jnp.asarray(self.from_grid_mat),
        name='atom_wise',
      )
    x = atomwise(x)
    x = x + x_res

    return x
